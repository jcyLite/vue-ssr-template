import Switch from '../../components/switch/switch.vue'

Switch.install = function (Vue) {
  Vue.component(Switch.name, Switch)
}

export default Switch
