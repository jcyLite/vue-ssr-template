const column1 = [
  {
    text: '剧毒',
    value: '剧毒'
  }, {
    text: '蚂蚁',
    value: '蚂蚁'
  },
  {
    text: '幽鬼',
    value: '幽鬼'
  },
  {
    text: '主宰',
    value: '主宰'
  },
  {
    text: '卡尔',
    value: '卡尔'
  },
  {
    text: '宙斯',
    value: '宙斯'
  },
  {
    text: '巫医',
    value: '巫医'
  }, {
    text: '巫妖',
    value: '巫妖'
  },
  {
    text: '神谕者',
    value: '神谕者'
  },
  {
    text: '撼地神牛',
    value: '神谕者'
  },
  {
    text: '蓝胖子',
    value: '蓝胖子'
  },
  {
    text: '水晶室女',
    value: '水晶室女'
  },
  {
    text: '莉娜',
    value: '莉娜'
  },
  {
    text: '斯拉克',
    value: '斯拉克'
  },
  {
    text: '斯拉达',
    value: '斯拉达'
  }
]

const column2 = [
  {
    text: '输出',
    value: '输出'
  }, {
    text: '控制',
    value: '控制'
  },
  {
    text: '核心',
    value: '核心'
  },
  {
    text: '爆发',
    value: '爆发'
  },
  {
    text: '辅助',
    value: '辅助'
  },
  {
    text: '打野',
    value: '打野'
  },
  {
    text: '逃生',
    value: '逃生'
  }, {
    text: '先手',
    value: '先手'
  }
]

const column3 = [
  {
    text: '梅肯',
    value: '梅肯'
  }, {
    text: '秘法鞋',
    value: '秘法鞋'
  },
  {
    text: '假腿',
    value: '假腿'
  },
  {
    text: '飞鞋',
    value: '飞鞋'
  },
  {
    text: '辉耀',
    value: '辉耀'
  },
  {
    text: '金箍棒',
    value: '金箍棒'
  }
]

const expressData = [
  {
    text: '顺丰',
    value: '顺丰'
  },
  {
    text: '中通',
    value: '中通'
  },
  {
    text: '圆通',
    value: '圆通'
  }
]

export {
  column1,
  column2,
  column3,
  expressData
}
