import Pot from './src'
export default Pot
